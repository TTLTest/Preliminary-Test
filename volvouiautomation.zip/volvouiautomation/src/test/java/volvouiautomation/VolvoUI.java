package volvouiautomation;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class VolvoUI 
{
	ExtentHtmlReporter htmlreporter;
	ExtentReports extent;
	WebDriver driver;
	
	@BeforeSuite
	public void testreportsetup()
	{
		htmlreporter = new ExtentHtmlReporter("VolvoTestReport.html");
		extent = new ExtentReports();
		extent.attachReporter(htmlreporter);
		
	}
	
	@BeforeTest
	public void webpagesetup()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\X235656\\Documents\\new version\\volvouiautomation\\chromedriver\\chromedriver.exe");
		driver=new ChromeDriver();
	}
	@SuppressWarnings("deprecation")
	@Test
	public void testcase1() throws IOException, InterruptedException 
	{
		ExtentTest tc1=extent.createTest("Test Case 1","Launching the volvo cars web page");
		ExtentTest tc2=extent.createTest("Test Case 2","Navigating to our cars section");
		ExtentTest tc3=extent.createTest("Test Case 3","Navigating to Electric Cars");
		ExtentTest tc4=extent.createTest("Test Case 3","Navigating to Hybrid Cars");
		ExtentTest tc5=extent.createTest("Test Case 3","Navigating to Mild Hybrid Cars");
		//Test case 1 Launching the webpage of volvocars
		driver.get("https://www.volvocars.com/intl/v/car-safety/a-million-more");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(100,TimeUnit.SECONDS);
		driver.manage().window().maximize();
		tc1.pass("VolvoCars Web URL launched sucessfully");
		tc1.log(Status.INFO, "Log verified");
		tc1.info("test case info");
		tc1.pass("Test Case 1 execution");
		tc1.addScreenCaptureFromPath("Screenshot.png");
		Thread.sleep(5000);
		// Accepting the cookies
		WebElement clickcookies=driver.findElement(By.id("onetrust-accept-btn-handler"));
		clickcookies.click();
		Thread.sleep(5000);
		//Test Case 2 Locating the webelement for our cars section
		WebElement ele1=driver.findElement(By.cssSelector("#nav\\:topNavCarMenu"));
		ele1.click();
		tc2.pass("Our cars section launched successfully");
		tc2.log(Status.INFO, "Log verified");
		tc2.info("test case info");
		tc2.pass("Test Case 2 execution");
		tc2.addScreenCaptureFromPath("Screenshot1.png");
		Thread.sleep(5000);
		//Test Case 3 Locating the webelement for Electric Type cars
		WebElement ele2=driver.findElement(By.id("site-nav-cars-menu-section-tab-0"));
		ele2.click();
		tc3.pass("Electric cars section launched successfully");
		tc2.log(Status.INFO, "Log verified");
		tc2.info("test case info");
		tc2.pass("Test Case 3 execution");
		tc2.addScreenCaptureFromPath("Screenshot2.png");
		Thread.sleep(3000);
		//Test Case 4 Locating the webelement for Hybrid Cars
		WebElement ele3=driver.findElement(By.id("site-nav-cars-menu-section-tab-1"));
		ele3.click();
		tc4.pass("Hybrid cars section launched successfully");
		tc4.log(Status.INFO, "Log verified");
		tc4.info("test case info");
		tc4.pass("Test Case 4 execution");
		tc4.addScreenCaptureFromPath("Screenshot3.png");
		Thread.sleep(3000);
		//Test Case 5, Locating the webelement for mild hybrids
		WebElement ele4=driver.findElement(By.id("site-nav-cars-menu-section-tab-2"));
		ele4.click();
		tc5.pass("Mild Hybrid cars section launched successfully");
		tc5.log(Status.INFO, "Log verified");
		tc5.info("test case info");
		tc5.pass("Test Case 5 execution");
		tc5.addScreenCaptureFromPath("Screenshot4.png");
	}
	@AfterTest
	public void exitpage()
	{
	driver.close();
	driver.quit();
	System.out.println("Test Completed Successfully");
	
	}
	@AfterSuite
	public void clearreport() 
	{
		extent.flush();
	}


}
