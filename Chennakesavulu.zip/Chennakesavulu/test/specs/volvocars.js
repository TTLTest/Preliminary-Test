// const volvohomeobj=require('../pageobjects/volvohome')
import Cookies from 'js-cookie'
describe('Volvo cars test',async()=>{

it('test case 1 with Cookies',async()=>{
    await browser.url("https://www.volvocars.com/intl/v/car-safety/a-million-more")
    await $('//button[text()="Accept"]').click()

    const cookiesget = await browser.getCookies()
    await browser.setCookies([
        {name: cookiesget[0].name, value: cookiesget[0].value,domain:'.volvocars.com',path:'/'},
        {name: cookiesget[1].name, value: cookiesget[1].value,domain:'.volvocars.com',path:'/'},
        {name: cookiesget[2].name, value: cookiesget[2].value,domain:'.volvocars.com',path:'/'},
        {name: cookiesget[3].name, value: cookiesget[3].value,domain:'.volvocars.com',path:'/'},
        {name: cookiesget[4].name, value: cookiesget[4].value,domain:'.volvocars.com',path:'/'},
        {name: cookiesget[5].name, value: cookiesget[5].value,domain:'.volvocars.com',path:'/'},
        {name: cookiesget[6].name, value: cookiesget[6].value,domain:'.volvocars.com',path:'/'},
        {name: cookiesget[7].name, value: cookiesget[7].value,domain:'.volvocars.com',path:'/'}
    ])

    // await browser.cookies
    await $("//em[text()='Our Cars']/..").click()

    await browser.pause(5000)
    // // await browser.waitUntil(async()=> await browser.isVisible("").getAttribute('data-sources'){
    // //     timeout: 5000,
    // //     timeoutMsg: 'Error on loading page'
    // // })
    await $("(//p[text()='Electric'])[1]").click()
})


// it('test case 2',async()=>{
//     await browser.url("https://www.volvocars.com/intl/v/car-safety/a-million-more")
//     await $('//button[text()="Accept"]').click()
//     await $("//em[text()='Our Cars']/..").click()
//     await browser.pause(3000)
//     await $("(//p[text()='Hybrid'])[1]").click()

// })

// it('test case 2',async()=>{
//     await browser.url("https://www.volvocars.com/intl/v/car-safety/a-million-more")
//     await $('//button[text()="Accept"]').click()
//     await $("//em[text()='Our Cars']/..").click()
//     await browser.pause(3000)
//     await $("(//p[text()='Mild hybrid'])[1]").click()

// })


})