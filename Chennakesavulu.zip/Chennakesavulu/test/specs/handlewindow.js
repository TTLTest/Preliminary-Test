describe('Handle multiple windows or tabs',async()=>{
    it('switch to tab',async()=>{
            await browser.url('https://opensource-demo.orangehrmlive.com/')
            await $("//a[text()='OrangeHRM, Inc']").click()
            await browser.switchWindow("orangehrm.com")
            await $("(//button[text()='Contact Sales'])[2]").click()
            await browser.closeWindow()
            await browser.quitWindow()

    })
})