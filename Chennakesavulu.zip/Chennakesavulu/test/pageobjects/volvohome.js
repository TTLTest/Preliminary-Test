class volvohome{


    get ourcars_link(){
        return $("//em[text()='Our Cars']")
    }

    get electriccars_link(){
        return $("(//p[text()='Electric'])[1]")
    }

    get hybridcars_link(){
        return $("(//p[text()='Hybrid'])[1]")
    }

    get electriccars_link(){
        return $("(//p[text()='Mild hybrids'])[1]")
    }

    async clickoncarslink(carstype){
       await this.carstype.click()
    }

}

module.exports=new volvohome() 