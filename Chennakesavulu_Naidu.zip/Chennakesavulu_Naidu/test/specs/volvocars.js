// const volvohomeobj=require('../pageobjects/volvohome')

describe('Volvo cars test',async()=>{

it('test case 1',async()=>{
    await browser.url("https://www.volvocars.com/intl/v/car-safety/a-million-more")
    await $('//button[text()="Accept"]').click()
    await $("//em[text()='Our Cars']/..").click()
    await browser.pause(3000)
    // await browser.waitUntil(async()=> await browser.isVisible("").getAttribute('data-sources'){
    //     timeout: 5000,
    //     timeoutMsg: 'Error on loading page'
    // })
    await $("(//p[text()='Electric'])[1]").click()

})


it('test case 2',async()=>{
    await browser.url("https://www.volvocars.com/intl/v/car-safety/a-million-more")
    await $('//button[text()="Accept"]').click()
    await $("//em[text()='Our Cars']/..").click()
    await browser.pause(3000)
    await $("(//p[text()='Hybrid'])[1]").click()

})

it('test case 2',async()=>{
    await browser.url("https://www.volvocars.com/intl/v/car-safety/a-million-more")
    await $('//button[text()="Accept"]').click()
    await $("//em[text()='Our Cars']/..").click()
    await browser.pause(3000)
    await $("(//p[text()='Mild hybrid'])[1]").click()

})


})